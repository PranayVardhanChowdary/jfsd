function callApi(METHOD, URL, DATA, SUCCESS) {
    var xhttp = new XMLHttpRequest();
    xhttp.open(METHOD, URL, true);
    xhttp.setRequestHeader('Content-Type', 'application/json');

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
            if (this.status == 200)
                SUCCESS(this.responseText);
            else
                alert("404: Service unavailable");
        }
    };

    xhttp.send(DATA);
}

function getCaptcha() {
    var url = "http://localhost:8080/captcha/getcaptcha/6";
    callApi("GET", url, "", loadCaptcha);
}

function loadCaptcha(res) {
    var captchaImage = document.getElementById("captchaImage");
    captchaImage.src = "data:image/png;base64," + res;
}

function validateCaptcha() {
    var captchaText = document.getElementById("captchaInput").value;

    if (captchaText.length === 0) {
        alert("Please enter the CAPTCHA.");
        return;
    }

    var url = "http://localhost:8080/captcha/validate/" + captchaText;
    callApi("GET", url, "", function (res) {
        var validationResult = document.getElementById("validationResult");
        validationResult.innerHTML = res;

        // Check if CAPTCHA validation is successful
        if (res === "Validation Success") {
            // Automatically trigger the login function
            login();
        }
    });
}


function login() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;

    var data = JSON.stringify({
        "username": username,
        "password": password,
    });

    fetch("http://localhost:8080/person/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: data
    })
    .then(response => response.text())
    .then(result => {
        if (result === "Successfully logged in") {
            // Fetch the user type and then redirect accordingly
            fetch("http://localhost:8080/person/getUserType?username=" + username)
            .then(response => response.text())
            .then(userType => {
                switch (userType) {
                    case "Student":
                        window.location.href = "student.html";
                        break;
                    case "University":
                        window.location.href = "university.html";
                        break;
                    case "Admin":
                        window.location.href = "admin.html";
                        break;
                    case "Company":
                        window.location.href = "company.html";
                        break;
                    default:
                        alert("Unknown user type");
                }
            });
        } else {
            alert(result);
        }
    })
    .catch(error => {
        console.error("Error:", error);
    });
}

// The callApi function is assumed to be defined elsewhere in your code
// It makes an HTTP request to your server


function handleValidationResult(res) {
    var validationResult = document.getElementById("validationResult");
    validationResult.innerHTML = res;
}

// Trigger the getCaptcha function when the page loads
window.onload = getCaptcha;
