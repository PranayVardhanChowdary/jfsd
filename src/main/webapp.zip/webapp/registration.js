
let isEmailVerified = false;

function handleEmailVerificationSuccess() 
{
    isEmailVerified = true;
    alert("Email sent successfully! Check your email for OTP.");
    document.getElementById("registrationMessage").textContent = "Email sent successfully!";
}

function handleEmailVerificationFailure() {
    document.getElementById("registrationMessage").textContent = "Email sending failed!";
}

document.getElementById("verifyEmailButton").addEventListener("click", function () {
    const email = document.getElementById("email").value;

    // Make an API call to send an email with OTP (customize the endpoint)
    fetch(`/email/send?toEmail=${email}`)
        .then((response) => response.text())
        .then((data) => {
            if (data === "Email send successfully") {
                handleEmailVerificationSuccess();
            } else {
                handleEmailVerificationFailure();
            }
        })
        .catch((error) => {
            console.error("Error sending email:", error);
        });
});



document.getElementById("verifyOTPButton").addEventListener("click", function () {
    const otp = document.getElementById("otp").value;

    fetch(`/email/verify?otp=${otp}`)
        .then((response) => response.text())
        .then((data) => {
            if (data === "OTP verification successful!") {
                handleOTPVerificationSuccess();
            } else {
                handleOTPVerificationFailure();
            }
        })
        .catch((error) => {
            console.error("Error verifying OTP:", error);
        });
});

// Function to handle successful OTP verification
function handleOTPVerificationSuccess() {
    alert("OTP verification successful!");
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const email = document.getElementById("email").value;
	  const university = document.getElementById("university").value;
    const type = document.getElementById("type").value;
    fetch("/person/register", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            username,
            password,
            email,
            university,
            type,
        }),
    })
        .then((response) => response.text())
        .then((registrationResult) => {
            alert(registrationResult);
        })
        .catch((error) => {
            console.error("Error registering user:", error);
        });
}

// Function to handle OTP verification failure
function handleOTPVerificationFailure() {
    alert("OTP verification failed!");
}
